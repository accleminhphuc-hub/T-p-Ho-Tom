/* ==========================================================
   TOM GAME STORE — PRODUCT DATA
   Admin chỉ cần chỉnh dữ liệu trong file này.
   Không có backend / database / checkout.
   ========================================================== */

const SHOP_CONFIG = {
  name: "TOM",
  fullName: "TOM GAME STORE",
  slogan: "Kho Chrat Game Cao Cấp",
  zalo: "https://zalo.me/84397183278",
  logo: "assets/images/logo.svg",
  adminName: "TOM ADMIN",
  adminInitial: "T",
  adminYears: "2024 — nay",
  adminDescription: "Dịch Vụ Cheat Game Hàng Đầu @.  Giờ Hoạt Động : 12h - 23h.  Contact / Zalo : 039.718.3278."
};

const products = [
  {
    id:"FF001", game:"Free Fire", shortGame:"FF", name:"AimLock Head V1 – V5", price:275000, priceLabel:"50K – 500K",
    image:"assets/images/product-tap-hoa-tom.png", rank:"hỗ trợ kéo tâm", level:1, skins:0, pets:0,
    status:"available", date:12,
    highlights:["Hỗ trợ kéo tâm","Headshot khoảng 90%–95%","Phiên bản V1–V5"],
    description:"Công cụ được giới thiệu với các phiên bản AimLock Head V1–V5, mô tả hỗ trợ kéo tâm và headshot khoảng 90%–95%."
  },
  {
    id:"FF002", game:"Free Fire", shortGame:"FF", name:"Aim Cổ", price:100000, priceLabel:"100K",
    image:"assets/images/product-tap-hoa-tom.png", rank:"Aim Cheat", level:2, skins:0, pets:0,
    status:"available", date:11,
    highlights:["Khoá Chặt vùng cổ","Kéo nhẹ là đỏ."],
    description:"Sản phẩm Aim Cổ. Mô tả do người bán cung cấp: tâm ghim chặt vùng cổ, kéo nhẹ là đỏ."
  },
  {
    id:"FF003", game:"Free Fire", shortGame:"FF", name:"Aim Drag", price:100000, priceLabel:"100K",
    image:"assets/images/product-tap-hoa-tom.png", rank:"Aim Cheat", level:3, skins:0, pets:0,
    status:"available", date:10,
    highlights:["Cheat New","Mô tả: lộ đỉnh đầu"],
    description:"Lộ Đỉnh Đầu , Nhích Nhẹ Là Đỏ , Tỉ Lệ Hs 90%."
  },
  {
    id:"FF004", game:"Free Fire", shortGame:"FF", name:"Aim Body", price:100000, priceLabel:"150K",
    image:"assets/images/product-tap-hoa-tom.png", rank:"Aim Cheat", level:4, skins:0, pets:0,
    status:"available", date:9,
    highlights:["Tỉ lệ headshot 100%","Mô tả: không còn máu vàng"],
    description:"Sản phẩm Aim Body có tỉ lệ headshot lên đến 100% , full đỏ toàn thân."
  },
  {
    id:"FF005", game:"Free Fire", shortGame:"FF", name:"Aim Bot", price:120000, priceLabel:"150K",
    image:"assets/images/product-tap-hoa-tom.png", rank:"Aim Cheat", level:5, skins:0, pets:0,
    status:"available", date:8,
    highlights:["Mô tả: đạn bám theo đầu","Bắn là đỏ"],
    description:"Sản phẩm Aim Bot với chức năng đạn dí theo đầu địch , ra đạn là auto full đỏ."
  },
  {
    id:"FF006", game:"Free Fire", shortGame:"FF", name:"Aim Cân Check R8", price:150000, priceLabel:"170K",
    image:"assets/images/product-tap-hoa-tom.png", rank:"Aim Cheat", level:6, skins:0, pets:0,
    status:"available", date:7,
    highlights:["cân check r8 cho ae đi kèo","Mô tả: kéo là đỏ"],
    description:"Ra đạn là full đỏ , cân check r8 , phù hợp cho ae đi kèo."
  },
  {
    id:"FF007", game:"Free Fire", shortGame:"FF", name:"App Akatsuki", price:150000, priceLabel:"50K – 250K",
    image:"assets/images/product-tap-hoa-tom.png", rank:"Ứng dụng", level:7, skins:0, pets:0,
    status:"available", date:6,
    highlights:["Nhiều chức năng","AimLegit","AimBot (theo mô tả)"],
    description:"App Akatsuki được giới thiệu với nhiều chức năng, gồm AimLegit và AimBot ,..."
  }
];

const testimonials = [
  { quote:"Sản phẩm chất lượng , shop uy tín , giá rẻ.", author:"Khách tham khảo #01" },
  { quote:"Shop minh bạch , buôn bán rõ ràng , hỗ trợ nhiệt tình cho khách hàng.", author:"Khách tham khảo #02" },
  { quote:"đồ chơi bên a kéo nhẹ là đỏ , giá rẻ nhưng rất chất lượng.", author:"Khách tham khảo #03" }
];
