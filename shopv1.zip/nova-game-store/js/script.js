/* ==========================================================
   NOVA GAME STORE — VANILLA JS
   Render / search / filter / sort / modal / theme / UX.
   ========================================================== */
(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const money = value => new Intl.NumberFormat("vi-VN").format(value) + "đ";

  const state = {
    query: "",
    game: "all",
    price: "all",
    rank: "all",
    level: "all",
    status: "all",
    sort: "newest"
  };

  const els = {
    grid: $("#productGrid"),
    empty: $("#emptyState"),
    summary: $("#resultSummary"),
    search: $("#searchInput"),
    game: $("#gameFilter"),
    price: $("#priceFilter"),
    rank: $("#rankFilter"),
    level: $("#levelFilter"),
    status: $("#statusFilter"),
    sort: $("#sortSelect"),
    filters: $("#filters"),
    filterToggle: $("#filterToggle"),
    reset: $("#resetFilters"),
    emptyReset: $("#emptyReset"),
    modal: $("#productModal"),
    modalImage: $("#modalImage"),
    modalTitle: $("#modalTitle"),
    modalGame: $("#modalGame"),
    modalPrice: $("#modalPrice"),
    modalId: $("#modalId"),
    modalStatus: $("#modalStatus"),
    modalSpecs: $("#modalSpecs"),
    modalDescription: $("#modalDescription"),
    modalHighlights: $("#modalHighlights"),
    modalContact: $("#modalContact"),
    galleryDots: $("#galleryDots"),
    toast: $("#toast")
  };

  function setConfig() {
    $$("[data-shop-name]").forEach(el => el.textContent = SHOP_CONFIG.name);
    $$("[data-shop-initial]").forEach(el => el.textContent = SHOP_CONFIG.name.charAt(0));
    $$("[data-admin-name]").forEach(el => el.textContent = SHOP_CONFIG.adminName);
    $$("[data-admin-initial]").forEach(el => el.textContent = SHOP_CONFIG.adminInitial);
    $$("[data-admin-years]").forEach(el => el.textContent = SHOP_CONFIG.adminYears);
    $$("[data-admin-description]").forEach(el => el.textContent = SHOP_CONFIG.adminDescription);
    $("#zaloLink").href = SHOP_CONFIG.zalo;
    $("#statProducts").textContent = `${products.length}+`;
    $("#statGames").textContent = `${new Set(products.map(p => p.game)).size}`;
  }

  function populateFilters() {
    const games = [...new Set(products.map(p => p.game))];
    const ranks = [...new Set(products.map(p => p.rank))];
    games.forEach(game => els.game.insertAdjacentHTML("beforeend", `<option value="${escapeHtml(game)}">${escapeHtml(game)}</option>`));
    ranks.forEach(rank => els.rank.insertAdjacentHTML("beforeend", `<option value="${escapeHtml(rank)}">${escapeHtml(rank)}</option>`));
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, char => ({
      "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
    }[char]));
  }

  function getFilteredProducts() {
    let list = products.filter(p => {
      const q = state.query.toLowerCase().trim();
      const searchable = [p.id, p.game, p.name, p.rank].join(" ").toLowerCase();
      if (q && !searchable.includes(q)) return false;
      if (state.game !== "all" && p.game !== state.game) return false;
      if (state.rank !== "all" && p.rank !== state.rank) return false;
      if (state.status !== "all" && p.status !== state.status) return false;

      if (state.price !== "all") {
        const [min, max] = state.price.split("-").map(Number);
        if (p.price < min || p.price > max) return false;
      }

      if (state.level !== "all") {
        const [min, max] = state.level.split("-").map(Number);
        if (p.level < min || p.level > max) return false;
      }
      return true;
    });

    if (state.sort === "priceAsc") list.sort((a,b) => a.price - b.price);
    else if (state.sort === "priceDesc") list.sort((a,b) => b.price - a.price);
    else list.sort((a,b) => b.date - a.date);
    return list;
  }

  function renderProducts() {
    const list = getFilteredProducts();
    els.grid.innerHTML = list.map(cardTemplate).join("");
    els.empty.hidden = list.length !== 0;
    els.summary.textContent = `${list.length} sản phẩm phù hợp / ${products.length} sản phẩm trong catalog`;

    $$(".detail-btn", els.grid).forEach(btn => {
      btn.addEventListener("click", () => openModal(btn.dataset.id));
    });
  }

  function cardTemplate(p) {
    const statusText = p.status === "reserved" ? "ĐÃ ĐƯỢC UPDATE" : "ĐÃ ĐƯỢC KIỂM DUYỆT";
    const chips = [
      p.highlights?.[0] || p.rank || null,
      p.highlights?.[1] || null,
      p.highlights?.[2] || null
    ].filter(Boolean).slice(0, 3);

    return `
      <article class="product-card reveal visible">
        <div class="product-image">
          <img src="${escapeHtml(p.image)}" alt="${escapeHtml(p.name)}" loading="lazy">
          <div class="product-overlay"></div>
          <span class="badge ${p.status} image-badge">${statusText}</span>
        </div>
        <div class="product-body">
          <div class="product-top"><span>${escapeHtml(p.id)}</span><span>${escapeHtml(p.shortGame)}</span></div>
          <h3>${escapeHtml(p.name)}</h3>
          <span class="product-game">${escapeHtml(p.game)}</span>
          <div class="spec-line">${chips.map(c => `<span class="spec-chip">${escapeHtml(c)}</span>`).join("")}</div>
          <div class="product-bottom">
            <div><span class="price-label">GIÁ THAM KHẢO</span><span class="price">${escapeHtml(p.priceLabel || money(p.price))}</span></div>
            <button class="detail-btn" data-id="${escapeHtml(p.id)}" type="button">XEM CHI TIẾT →</button>
          </div>
        </div>
      </article>
    `;
  }

  function renderGames() {
    const map = {};
    products.forEach(p => map[p.game] = (map[p.game] || 0) + 1);
    $("#gameCategories").innerHTML = Object.entries(map).map(([game, count]) => {
      const sample = products.find(p => p.game === game);
      return `
        <button class="game-card" type="button" data-game="${escapeHtml(game)}">
          <span class="game-icon">${escapeHtml(sample.shortGame)}</span>
          <span class="game-arrow">↗</span>
          <h3>${escapeHtml(game)}</h3>
          <span>${count} sản phẩm</span>
        </button>`;
    }).join("");

    $$(".game-card").forEach(card => card.addEventListener("click", () => {
      state.game = card.dataset.game;
      els.game.value = state.game;
      renderProducts();
      $("#inventory").scrollIntoView({behavior:"smooth"});
      $$(".game-card").forEach(c => c.classList.toggle("active", c === card));
    }));
  }

  function renderTestimonials() {
    $("#testimonialGrid").innerHTML = testimonials.map(t => `
      <article class="testimonial reveal visible">
        <div class="stars">★★★★★</div>
        <blockquote>“${escapeHtml(t.quote)}”</blockquote>
        <small>${escapeHtml(t.author)}</small>
        <div class="demo-note">Nội dung mẫu — thay thế trong <b>js/products.js</b></div>
      </article>
    `).join("");
  }

  function openModal(id) {
    const p = products.find(item => item.id === id);
    if (!p) return;

    els.modalImage.src = p.image;
    els.modalImage.alt = p.name;
    els.modalTitle.textContent = p.name;
    els.modalGame.textContent = p.game.toUpperCase();
    els.modalPrice.textContent = p.priceLabel || money(p.price);
    els.modalId.textContent = p.id;
    els.modalStatus.className = `badge ${p.status}`;
    els.modalStatus.textContent = p.status === "reserved" ? "ĐANG GIỮ" : "ĐANG THAM KHẢO";
    els.modalDescription.textContent = p.description;

    const specs = [
      ["Phân loại", p.rank || "—"], ["Mã sản phẩm", p.id],
      ["Giá niêm yết", p.priceLabel || money(p.price)], ["Danh mục", p.game || "—"]
    ];
    els.modalSpecs.innerHTML = specs.map(([label,value]) => `<div class="spec"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`).join("");
    els.modalHighlights.innerHTML = p.highlights.map(h => `<span class="modal-highlight">${escapeHtml(h)}</span>`).join("");
    els.modalContact.href = SHOP_CONFIG.zalo;

    els.galleryDots.innerHTML = `<span class="gallery-dot active"></span><span class="gallery-dot"></span><span class="gallery-dot"></span>`;
    els.modal.classList.add("open");
    els.modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
  }

  function closeModal() {
    els.modal.classList.remove("open");
    els.modal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
  }

  function syncFilters() {
    state.query = els.search.value;
    state.game = els.game.value;
    state.price = els.price.value;
    state.rank = els.rank.value;
    state.level = els.level.value;
    state.status = els.status.value;
    state.sort = els.sort.value;
    renderProducts();
  }

  function resetFilters() {
    state.query = ""; state.game = "all"; state.price = "all"; state.rank = "all"; state.level = "all"; state.status = "all"; state.sort = "newest";
    els.search.value = ""; els.game.value = "all"; els.price.value = "all"; els.rank.value = "all"; els.level.value = "all"; els.status.value = "all"; els.sort.value = "newest";
    $$(".game-card").forEach(c => c.classList.remove("active"));
    renderProducts();
  }

  function setupEvents() {
    [els.search, els.game, els.price, els.rank, els.level, els.status, els.sort].forEach(el => {
      el.addEventListener(el === els.search ? "input" : "change", syncFilters);
    });
    els.reset.addEventListener("click", resetFilters);
    els.emptyReset.addEventListener("click", resetFilters);
    els.filterToggle.addEventListener("click", () => els.filters.classList.toggle("open"));

    $$("[data-close-modal]").forEach(el => el.addEventListener("click", closeModal));
    document.addEventListener("keydown", e => {
      if (e.key === "Escape") closeModal();
      if (e.key === "/" && document.activeElement.tagName !== "INPUT") {
        e.preventDefault(); els.search.focus();
      }
    });

    $("#menuToggle").addEventListener("click", () => $("#mobileMenu").classList.toggle("open"));
    $$("#mobileMenu a").forEach(a => a.addEventListener("click", () => $("#mobileMenu").classList.remove("open")));

    $("#themeToggle").addEventListener("click", () => {
      const root = document.documentElement;
      const next = root.dataset.theme === "light" ? "dark" : "light";
      root.dataset.theme = next;
      localStorage.setItem("nova-theme", next);
      showToast(next === "light" ? "Đã chuyển sang Light Mode" : "Đã chuyển sang Dark Mode");
    });

    window.addEventListener("scroll", () => {
      $("#backTop").classList.toggle("show", window.scrollY > 600);
    }, {passive:true});
    $("#backTop").addEventListener("click", () => window.scrollTo({top:0,behavior:"smooth"}));

    window.addEventListener("click", e => {
      const link = e.target.closest("#heroContact");
      if (link) e.preventDefault();
    });
  }

  function setupReveal() {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    }, {threshold:.08});
    $$(".reveal").forEach(el => observer.observe(el));
  }

  function setupParticles() {
    const wrap = $("#particles");
    const count = window.matchMedia("(max-width: 700px)").matches ? 16 : 28;
    for (let i=0;i<count;i++) {
      const dot = document.createElement("i");
      dot.className = "particle";
      dot.style.left = `${Math.random()*100}%`;
      dot.style.top = `${Math.random()*100}%`;
      dot.style.animationDelay = `${Math.random()*7}s`;
      dot.style.animationDuration = `${6 + Math.random()*7}s`;
      wrap.appendChild(dot);
    }
  }

  function setupTheme() {
    const saved = localStorage.getItem("nova-theme");
    if (saved === "light") document.documentElement.dataset.theme = "light";
  }

  function showToast(message) {
    els.toast.textContent = message;
    els.toast.classList.add("show");
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => els.toast.classList.remove("show"), 2200);
  }

  function init() {
    setupTheme();
    setConfig();
    populateFilters();
    renderGames();
    renderProducts();
    renderTestimonials();
    setupEvents();
    setupReveal();
    setupParticles();
  }

  init();
})();
