# NOVA GAME STORE — Static Premium Catalog

Website catalog bán/giới thiệu acc game dạng **static website**, không backend.

## Công nghệ

- HTML5
- CSS3
- Vanilla JavaScript
- Google Fonts CDN (Inter + Manrope)

Không cần:
- npm
- Node.js
- database
- backend
- API server
- login
- thanh toán
- giỏ hàng
- checkout

## Chạy

Mở trực tiếp:

`index.html`

Hoặc deploy nguyên thư mục lên GitHub Pages / Netlify / Vercel / static hosting.

## Cấu trúc

```text
/
├── index.html
├── css/
│   └── style.css
├── js/
│   ├── products.js
│   └── script.js
├── assets/
│   ├── images/
│   └── icons/
└── README.md
```

## Chỉnh shop

Mở `js/products.js`.

### Cấu hình thương hiệu

```js
const SHOP_CONFIG = {
  name: "NOVA",
  fullName: "NOVA GAME STORE",
  slogan: "Kho Acc Game Cao Cấp",
  facebook: "https://facebook.com/",
  zalo: "https://zalo.me/",
  telegram: "https://t.me/",
  logo: "assets/images/logo.svg",
  adminName: "NOVA ADMIN",
  adminInitial: "N",
  adminYears: "2019 — nay",
  adminDescription: "..."
};
```

Chỉ cần thay các giá trị trên để cập nhật thông tin toàn website.

### Thêm / sửa / xóa sản phẩm

Toàn bộ sản phẩm nằm trong:

`const products = [...]`

Mỗi object có:

- `id`
- `game`
- `shortGame`
- `name`
- `price`
- `image`
- `rank`
- `level`
- `skins`
- `pets`
- `status`
- `date`
- `highlights`
- `description`

Website tự render card, search, filter, sort và modal từ dữ liệu này.

## Ảnh

Các file SVG trong `assets/images/` là placeholder local để website chạy ngay không cần server ảnh.

Có thể thay bằng:

```text
assets/images/ff001.jpg
```

và sửa:

```js
image: "assets/images/ff001.jpg"
```

## Liên hệ

Website chỉ mở link liên hệ admin. Không có hệ thống mua hàng, thanh toán hoặc thu thập thông tin khách.

## Ghi chú

- Testimonials hiện được ghi rõ là nội dung demo mẫu.
- Giá và thông tin sản phẩm là dữ liệu demo.
- Không nên dùng dữ liệu demo như thông tin giao dịch thực tế.
